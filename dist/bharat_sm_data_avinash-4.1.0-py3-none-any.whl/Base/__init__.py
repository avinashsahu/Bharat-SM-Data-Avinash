from Base.CustomRequest import CustomSession
from Base.NSEBase import NSEBase